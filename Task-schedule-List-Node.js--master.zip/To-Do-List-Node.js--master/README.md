# Todo List

This is my second full stack project. Made with HTML, CSS, Javascript.

Frameworks used: Bootstrap, Node.js, Express.js, EJS, Mongoose.
Database: MongoDB (deployed onto Mongo Atlas)

Code deployed onto Heroku. Check out: [my todo list app](https://desolate-reef-49579.herokuapp.com/work)
